package com.customerportal.bean;

public class CustomAttachments {

	private String id;
	private String facility;
	private String type;
	private String g360URL;
	private String source;
	private String description;
	private String name;
	private String reportDatae;
	private String active;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getG360URL() {
		return g360URL;
	}
	public void setG360URL(String g360url) {
		g360URL = g360url;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getReportDatae() {
		return reportDatae;
	}
	public void setReportDatae(String reportDatae) {
		this.reportDatae = reportDatae;
	}
	
}
