package com.customerportal.bean;

public class Leaktestresults {
	private String id;
	private String name;
	private String facility__c;
	private String fid__c;
	private String date__c;
	private String hours__c;
	private String rate__c;
	private String result__c;
	private String starttime__c;
	private String tank__c;
	private String testtype__c;
	private String type__c;
	private String volume__c;
	private String viewed="false";
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFacility__c() {
		return facility__c;
	}
	public void setFacility__c(String facility__c) {
		this.facility__c = facility__c;
	}
	public String getFid__c() {
		return fid__c;
	}
	public void setFid__c(String fid__c) {
		this.fid__c = fid__c;
	}
	public String getDate__c() {
		return date__c;
	}
	public void setDate__c(String date__c) {
		this.date__c = date__c;
	}
	public String getHours__c() {
		return hours__c;
	}
	public void setHours__c(String hours__c) {
		this.hours__c = hours__c;
	}
	public String getRate__c() {
		return rate__c;
	}
	public void setRate__c(String rate__c) {
		this.rate__c = rate__c;
	}
	public String getResult__c() {
		return result__c;
	}
	public void setResult__c(String result__c) {
		this.result__c = result__c;
	}
	public String getStarttime__c() {
		return starttime__c;
	}
	public void setStarttime__c(String starttime__c) {
		this.starttime__c = starttime__c;
	}
	public String getTank__c() {
		return tank__c;
	}
	public void setTank__c(String tank__c) {
		this.tank__c = tank__c;
	}
	public String getTesttype__c() {
		return testtype__c;
	}
	public void setTesttype__c(String testtype__c) {
		this.testtype__c = testtype__c;
	}
	public String getType__c() {
		return type__c;
	}
	public void setType__c(String type__c) {
		this.type__c = type__c;
	}
	public String getVolume__c() {
		return volume__c;
	}
	public void setVolume__c(String volume__c) {
		this.volume__c = volume__c;
	}
	public void setViewed(String viewed) {
		this.viewed = viewed;
	}
	public String getViewed() {
		return viewed;
	}
}
