package com.customerportal.bean;

public class Tankstatusreport {
	private String id;
	private String Name;
	private String facility__c;
	private String fid__c;
	private String product__c;
	private String date__c;
	private String status__c;
	private String tank__c;
	private String hours__c;
	private String rate__c;
	private String result__c;
	private String startTime__c;
	private String viewed="false";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getFacility__c() {
		return facility__c;
	}
	public void setFacility__c(String facility__c) {
		this.facility__c = facility__c;
	}
	public String getFid__c() {
		return fid__c;
	}
	public void setFid__c(String fid__c) {
		this.fid__c = fid__c;
	}
	public String getProduct__c() {
		return product__c;
	}
	public void setProduct__c(String product__c) {
		this.product__c = product__c;
	}
public void setDate__c(String date__c) {
	this.date__c = date__c;
}
public String getDate__c() {
	return date__c;
}
	public String getStatus__c() {
		return status__c;
	}
	public void setStatus__c(String status__c) {
		this.status__c = status__c;
	}
	public String getTank__c() {
		return tank__c;
	}
	public void setTank__c(String tank__c) {
		this.tank__c = tank__c;
	}
	public String getHours__c() {
		return hours__c;
	}
	public void setHours__c(String hours__c) {
		this.hours__c = hours__c;
	}
	public String getRate__c() {
		return rate__c;
	}
	public void setRate__c(String rate__c) {
		this.rate__c = rate__c;
	}
	public String getResult__c() {
		return result__c;
	}
	public void setResult__c(String result__c) {
		this.result__c = result__c;
	}
	public String getStartTime__c() {
		return startTime__c;
	}
	public void setStartTime__c(String startTime__c) {
		this.startTime__c = startTime__c;
	}
	
	public void setViewed(String viewed) {
		this.viewed = viewed;
	}

	public String getViewed() {
		return viewed;
	}
	
	

}
