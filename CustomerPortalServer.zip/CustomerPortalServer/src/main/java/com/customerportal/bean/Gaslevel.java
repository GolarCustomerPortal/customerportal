package com.customerportal.bean;

public class Gaslevel {
	private String facilityId;
	private String gaslevels;

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getGaslevels() {
		return gaslevels;
	}

	public void setGaslevels(String gaslevels) {
		this.gaslevels = gaslevels;
	}

}
